// ═══════════════════════════════════════════════
// env.js — الإعدادات الثابتة (لا يوجد فيها أي سر)
// ═══════════════════════════════════════════════
window.ENV = {
  // رابط الـ Worker على Cloudflare
  WORKER_URL: "https://moonbook.ksbaakaa0.workers.dev"
};
