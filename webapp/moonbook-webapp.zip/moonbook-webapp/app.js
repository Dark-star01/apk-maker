// ═══════════════════════════════════════════════
// app.js — منطق Moonbook
// كل التخزين على الجهاز (localStorage) وبحدود ثابتة
// ═══════════════════════════════════════════════
(() => {
  'use strict';

  // ─── إعدادات ───
  const WORKER = ((window.ENV && window.ENV.WORKER_URL) || '').replace(/\/+$/, '');
  const HOUR = 60 * 60 * 1000;
  // حدود التخزين: لا شيء يكبر بلا سقف
  const LIM = { favs: 100, prog: 50, hist: 30, cache: 20 };
  const GENRES = ['الكل', 'أكشن', 'مغامرات', 'فانتازيا', 'إيسيكاي', 'رومانسي', 'كوميدي', 'دراما', 'نظام', 'سحر', 'وحوش', 'فنون قتال', 'خيال علمي', 'غموض', 'إثارة', 'حريم', 'خارق للطبيعة', 'ويب تون'];

  // ─── أدوات عامة ───
  const $ = (s, r = document) => r.querySelector(s);
  const app = $('#app');
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const httpsOnly = (u) => (/^https:\/\//.test(u || '') ? u : '');

  // ═══ التخزين المحلي ═══
  const Store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} },
  };

  // ─── التفضيلات ───
  const Prefs = {
    get() { return Object.assign({ theme: 'dark' }, Store.get('mb_prefs', {})); },
    set(p) { Store.set('mb_prefs', Object.assign(this.get(), p)); applyTheme(); },
  };
  function applyTheme() {
    let t = Prefs.get().theme;
    if (t === 'auto') t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', t);
    const m = $('meta[name="theme-color"]');
    if (m) m.content = t === 'light' ? '#ffffff' : '#07070a';
  }

  // ─── المفضلة (حد 100) ───
  const Favs = {
    list() { return Store.get('mb_favs', []); },
    has(slug) { return this.list().some((f) => f.slug === slug); },
    toggle(it) {
      const l = this.list();
      const i = l.findIndex((f) => f.slug === it.slug);
      if (i >= 0) { l.splice(i, 1); Store.set('mb_favs', l); return 'removed'; }
      if (l.length >= LIM.favs) return 'full';
      l.unshift({ slug: it.slug, title: it.title, cover: it.cover });
      Store.set('mb_favs', l);
      return 'added';
    },
  };

  // ─── تقدم القراءة (آخر 50 عمل) ───
  const Prog = {
    all() { return Store.get('mb_prog', {}); },
    get(slug) { return this.all()[slug] || null; },
    save(slug, data) {
      const all = this.all();
      all[slug] = Object.assign(all[slug] || {}, data, { t: Date.now() });
      const keys = Object.keys(all);
      if (keys.length > LIM.prog) {
        keys.sort((a, b) => all[a].t - all[b].t).slice(0, keys.length - LIM.prog).forEach((k) => delete all[k]);
      }
      Store.set('mb_prog', all);
    },
    recent(n) {
      const all = this.all();
      return Object.keys(all).map((k) => Object.assign({ slug: k }, all[k])).sort((a, b) => b.t - a.t).slice(0, n);
    },
  };

  // ─── سجل الاستخدام (آخر 30 فصل) ───
  const Hist = {
    list() { return Store.get('mb_hist', []); },
    add(e) {
      const l = this.list();
      if (l[0] && l[0].slug === e.slug && l[0].c === e.c) return;
      l.unshift(Object.assign({ t: Date.now() }, e));
      Store.set('mb_hist', l.slice(0, LIM.hist));
    },
    clear() { Store.del('mb_hist'); },
  };

  // ─── كاش الشبكة (ساعة واحدة، حد 20 عنصر) ───
  const Cache = {
    all() { return Store.get('mb_cache', {}); },
    get(key, allowStale) {
      const e = this.all()[key];
      if (!e) return null;
      if (!allowStale && Date.now() - e.t > HOUR) return null;
      return e.d;
    },
    put(key, d) {
      const all = this.all();
      all[key] = { t: Date.now(), d };
      const keys = Object.keys(all);
      if (keys.length > LIM.cache) {
        keys.sort((a, b) => all[a].t - all[b].t).slice(0, keys.length - LIM.cache).forEach((k) => delete all[k]);
      }
      if (!Store.set('mb_cache', all)) Store.set('mb_cache', { [key]: { t: Date.now(), d } });
    },
    // حذف المنتهي (يُستدعى عند فتح التطبيق وهو متصل)
    sweep() {
      const all = this.all();
      let changed = false;
      for (const k in all) if (Date.now() - all[k].t > HOUR) { delete all[k]; changed = true; }
      if (changed) Store.set('mb_cache', all);
    },
    clear() { Store.del('mb_cache'); },
  };

  // ═══ الشبكة ═══
  // نجرب الكاش الطازج أولاً، ثم الشبكة، وإذا فشلت نستخدم النسخة القديمة إن وجدت
  async function api(path) {
    const fresh = Cache.get(path);
    if (fresh) return fresh;
    try {
      if (!WORKER) throw new Error('WORKER_URL غير مضبوط في env.js');
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 20000);
      const r = await fetch(WORKER + path, { signal: ctl.signal });
      clearTimeout(timer);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'HTTP ' + r.status);
      Cache.put(path, data);
      return data;
    } catch (e) {
      const old = Cache.get(path, true);
      if (old) return old;
      throw e;
    }
  }

  // ═══ واجهة مساعدة ═══
  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 2200);
  }

  function syncOnline() {
    const off = !navigator.onLine;
    $('#offline').hidden = !off;
    document.body.classList.toggle('is-offline', off);
  }
  window.addEventListener('online', () => { syncOnline(); toast('عاد الاتصال'); });
  window.addEventListener('offline', syncOnline);

  const skeletonGrid = (n) => '<div class="grid">' + '<div class="card sk"></div>'.repeat(n || 8) + '</div>';

  function errorBox(e) {
    const offline = !navigator.onLine;
    return '<div class="state"><strong>' + (offline ? 'لا يوجد اتصال' : 'تعذّر التحميل') + '</strong>' +
      '<p>' + (offline ? 'اتصل بالإنترنت ثم أعد المحاولة. الصفحات التي فتحتها مؤخراً تظهر بدون اتصال.' : 'تحقق من الاتصال ثم أعد المحاولة.') + '</p>' +
      (e && e.message ? '<small>' + esc(e.message) + '</small>' : '') +
      '<button class="btn primary" data-retry>إعادة المحاولة</button></div>';
  }

  function coverImg(url, cls) {
    const u = httpsOnly(url);
    return u
      ? '<img ' + (cls ? 'class="' + cls + '" ' : '') + 'src="' + esc(u) + '" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
      : '<div class="ph"></div>';
  }
  function hideBrokenImgs(root) {
    root.querySelectorAll('img').forEach((img) => img.addEventListener('error', () => img.remove(), { once: true }));
  }

  function card(it) {
    const a = document.createElement('a');
    a.className = 'card';
    a.href = '#/manhwa/' + encodeURIComponent(it.slug);
    const u = httpsOnly(it.cover);
    a.innerHTML =
      (u ? '<img src="' + esc(u) + '" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">' : '') +
      (it.type ? '<span class="tag">' + esc(it.type) + '</span>' : '') +
      '<div class="cap"><div class="t">' + esc(it.title) + '</div>' +
      '<div class="n">' + esc(it.chapters ? it.chapters + ' فصل' : (it.status || '')) + '</div></div>';
    hideBrokenImgs(a);
    return a;
  }

  // رقم يُعرَّف لكل عملية رسم، لتجاهل ردود الشبكة المتأخرة بعد مغادرة الصفحة
  let rid = 0;
  const route = (fn) => (params) => fn(params, ++rid);

  // ═══════════════════════════════════════════════
  // الصفحة الرئيسية: بحث + تصنيف + شبكة
  // ═══════════════════════════════════════════════
  const home = { q: '', genre: '', items: [], page: 1, more: false, loaded: false, scroll: 0, req: 0 };

  function renderHome() {
    app.innerHTML =
      '<header class="top"><h1>Moon<span>book</span></h1></header>' +
      '<div class="searchbar"><input id="q" type="search" enterkeyhint="search" autocomplete="off" placeholder="ابحث باسم المانهوا" value="' + esc(home.q) + '"></div>' +
      '<div class="chips" id="chips"></div>' +
      '<div id="cont"></div>' +
      '<div id="list"></div>';

    paintChips();
    paintContinue();

    let tm;
    $('#q').addEventListener('input', (e) => {
      clearTimeout(tm);
      tm = setTimeout(() => {
        const v = e.target.value.trim();
        if (v.length === 1 || v === home.q) return; // حرف واحد: ننتظر
        home.q = v;
        if (v) home.genre = '';
        paintChips();
        paintContinue();
        loadHome(true);
      }, 450);
    });

    if (home.loaded) { paintList(); window.scrollTo(0, home.scroll); } else loadHome(true);
    return () => { home.scroll = window.scrollY; };
  }

  function paintChips() {
    const box = $('#chips');
    if (!box) return;
    box.innerHTML = GENRES.map((g) => {
      const on = (g === 'الكل' && !home.genre) || g === home.genre;
      return '<button class="chip" aria-pressed="' + on + '" data-g="' + esc(g) + '">' + esc(g) + '</button>';
    }).join('');
    box.onclick = (e) => {
      const b = e.target.closest('.chip');
      if (!b) return;
      home.genre = b.dataset.g === 'الكل' ? '' : b.dataset.g;
      home.q = '';
      $('#q').value = '';
      paintChips();
      paintContinue();
      loadHome(true);
    };
  }

  // شريط "متابعة القراءة" (يظهر في التصفح العادي فقط)
  function paintContinue() {
    const box = $('#cont');
    if (!box) return;
    const items = home.q || home.genre ? [] : Prog.recent(10).filter((p) => p.c != null);
    if (!items.length) { box.innerHTML = ''; return; }
    box.innerHTML = '<div class="sect">متابعة القراءة</div><div class="cont">' + items.map((p) =>
      '<a class="mini" href="#/read/' + encodeURIComponent(p.slug) + '/' + p.c + '">' + coverImg(p.cover) +
      '<div><div class="mt">' + esc(p.title || p.slug) + '</div><div class="mc">الفصل ' + esc(p.c) + '</div></div></a>'
    ).join('') + '</div>';
    hideBrokenImgs(box);
  }

  async function loadHome(reset) {
    const my = ++home.req;
    const box = $('#list');
    if (!box) return;
    if (reset) { home.items = []; home.page = 1; home.more = false; box.innerHTML = skeletonGrid(8); }
    const searching = home.q.length >= 2;
    try {
      const data = searching
        ? await api('/search?q=' + encodeURIComponent(home.q))
        : await api('/browse?page=' + home.page + (home.genre ? '&genre=' + encodeURIComponent(home.genre) : ''));
      if (my !== home.req || !$('#list')) return;
      const seen = new Set(home.items.map((i) => i.slug));
      (data.results || []).forEach((i) => { if (!seen.has(i.slug)) home.items.push(i); });
      home.more = !!data.hasMore && !searching;
      home.loaded = true;
      paintList();
    } catch (e) {
      if (my !== home.req || !$('#list')) return;
      if (!reset) home.page--;
      if (reset || !home.items.length) {
        box.innerHTML = errorBox(e);
        box.querySelector('[data-retry]').onclick = () => loadHome(true);
      } else { paintList(); toast('تعذّر تحميل المزيد'); }
    }
  }

  function paintList() {
    const box = $('#list');
    if (!box) return;
    if (!home.items.length) {
      box.innerHTML = '<div class="state"><strong>لا توجد نتائج</strong><p>جرّب اسماً آخر أو تصنيفاً مختلفاً.</p></div>';
      return;
    }
    box.innerHTML = '<div class="grid"></div>' + (home.more ? '<div class="more"><button class="btn" id="more">عرض المزيد</button></div>' : '');
    const grid = box.firstElementChild;
    const frag = document.createDocumentFragment();
    home.items.forEach((it) => frag.appendChild(card(it)));
    grid.appendChild(frag);
    const more = $('#more');
    if (more) more.onclick = () => { more.disabled = true; more.textContent = 'جارٍ التحميل…'; home.page++; loadHome(false); };
  }

  // ═══════════════════════════════════════════════
  // صفحة العمل: التفاصيل + قائمة الفصول
  // ═══════════════════════════════════════════════
  function renderSeries({ slug }, my) {
    app.innerHTML = '<header class="top"><a class="back" href="#/">رجوع</a></header><div id="sbody">' + skeletonGrid(2) + '</div>';
    const load = () => {
      api('/series/' + encodeURIComponent(slug)).then((s) => {
        if (my !== rid) return;
        paintSeries(s);
      }).catch((e) => {
        if (my !== rid) return;
        const b = $('#sbody');
        b.innerHTML = errorBox(e);
        b.querySelector('[data-retry]').onclick = () => { b.innerHTML = skeletonGrid(2); load(); };
      });
    };
    load();
  }

  function paintSeries(s) {
    const body = $('#sbody');
    const chs = s.chapters || [];
    const prog = Prog.get(s.slug);
    const cur = prog && chs.includes(prog.c) ? prog.c : null;
    const startAt = cur != null ? cur : chs[0];
    let asc = false;

    body.innerHTML =
      '<section class="sh">' + coverImg(s.cover) +
      '<div class="si"><h2>' + esc(s.title) + '</h2>' +
      '<div><span class="pill">' + esc(s.status) + '</span></div>' +
      '<div class="meta">' + chs.length + ' فصل</div>' +
      '<div class="tags">' + (s.genres || []).map((g) => '<span>' + esc(g) + '</span>').join('') + '</div></div></section>' +
      '<div class="actions">' +
      (chs.length ? '<a class="btn primary" href="#/read/' + encodeURIComponent(s.slug) + '/' + startAt + '">' + (cur != null ? 'متابعة من الفصل ' + cur : 'ابدأ القراءة') + '</a>' : '') +
      '<button class="btn" id="fav"></button></div>' +
      (s.description ? '<p class="desc" id="desc">' + esc(s.description) + '</p>' : '') +
      '<div class="chead"><h3>الفصول</h3><button class="btn sm" id="sort"></button></div>' +
      '<div class="chs" id="chs"></div>';
    hideBrokenImgs(body);

    const favBtn = $('#fav');
    const paintFav = () => {
      const on = Favs.has(s.slug);
      favBtn.textContent = on ? 'في المفضلة' : 'أضف للمفضلة';
      favBtn.classList.toggle('on', on);
      favBtn.setAttribute('aria-pressed', on);
    };
    paintFav();
    favBtn.onclick = () => {
      const r = Favs.toggle(s);
      if (r === 'full') toast('المفضلة ممتلئة (' + LIM.favs + ' عمل)');
      else toast(r === 'added' ? 'أُضيف إلى المفضلة' : 'أُزيل من المفضلة');
      paintFav();
    };

    const desc = $('#desc');
    if (desc) desc.onclick = () => desc.classList.toggle('open');

    const paintChs = () => {
      const list = asc ? chs : chs.slice().reverse();
      $('#chs').innerHTML = list.map((n) =>
        '<a class="ch' + (n === cur ? ' cur' : '') + '" href="#/read/' + encodeURIComponent(s.slug) + '/' + n + '">' + n + '</a>').join('');
      $('#sort').textContent = asc ? 'الأحدث أولاً' : 'الأقدم أولاً';
    };
    paintChs();
    $('#sort').onclick = () => { asc = !asc; paintChs(); };
    if (!chs.length) $('#chs').innerHTML = '<div class="state">لا توجد فصول متاحة.</div>';
  }

  // ═══════════════════════════════════════════════
  // القارئ: تمرير عمودي، تحميل كسول، قص الصور الطويلة
  // ═══════════════════════════════════════════════
  function renderReader({ slug, num }, my) {
    const n = Number(num);
    app.innerHTML =
      '<div class="reader" id="rd">' +
      '<div class="rbar top"><a class="back" href="#/manhwa/' + encodeURIComponent(slug) + '">الفصول</a><div class="rt" id="rt">الفصل ' + esc(num) + '</div><div class="pi" id="pi"></div></div>' +
      '<div id="pages">' + skeletonGrid(1) + '</div>' +
      '<div class="rend" id="rend"></div>' +
      '<div class="rbar bot"><button class="btn sm" id="bprev" disabled>الفصل السابق</button><button class="btn sm primary" id="bnext" disabled>الفصل التالي</button></div>' +
      '</div>';

    const pagesBox = $('#pages');
    let wrappers = [];
    let io = null;
    let meta = null;            // بيانات العمل (العنوان والغلاف)
    let neighbors = { prev: null, next: null };
    let idx = 0;
    let lastY = window.scrollY;
    let tick = null;
    let prefetched = false;

    const prev = Prog.get(slug);
    const resume = prev && prev.c === n ? prev.p || 0 : 0;

    const persist = () => {
      const d = { c: n, p: idx };
      if (meta) { d.title = meta.title; d.cover = meta.cover; }
      Prog.save(slug, d);
    };

    // تحميل صفحة واحدة، وقصها إلى شرائح إذا كانت طويلة جداً
    function loadPage(w) {
      if (w.dataset.state) return;
      w.dataset.state = 'loading';
      const img = new Image();
      img.referrerPolicy = 'no-referrer';
      img.decoding = 'async';
      img.onload = () => {
        w.dataset.state = 'done';
        const nw = img.naturalWidth, nh = img.naturalHeight;
        const ratio = nh / nw;
        w.textContent = '';
        if (ratio <= 3) {
          img.className = 'pimg';
          w.appendChild(img);
        } else {
          const slices = Math.ceil(ratio / 2.5);
          for (let i = 0; i < slices; i++) {
            const s = document.createElement('div');
            s.className = 'slice';
            s.style.aspectRatio = nw + ' / ' + (nh / slices);
            s.style.backgroundImage = 'url("' + img.src.replace(/"/g, '%22') + '")';
            s.style.backgroundPosition = '0 ' + (i / (slices - 1)) * 100 + '%';
            w.appendChild(s);
          }
        }
        w.classList.add('ld');
      };
      img.onerror = () => {
        w.dataset.state = '';
        const r = document.createElement('div');
        r.className = 'retry';
        r.innerHTML = '<span>' + (navigator.onLine ? 'تعذّر تحميل الصورة' : 'لا يوجد اتصال') + '</span><button class="btn sm">إعادة المحاولة</button>';
        r.querySelector('button').onclick = (ev) => { ev.stopPropagation(); r.remove(); loadPage(w); };
        w.appendChild(r);
      };
      img.src = w.dataset.src;
    }

    function track() {
      if (!wrappers.length) return;
      let i = wrappers.length - 1;
      for (let k = 0; k < wrappers.length; k++) {
        if (wrappers[k].getBoundingClientRect().bottom > window.innerHeight * 0.25) { i = k; break; }
      }
      idx = i;
      const pi = $('#pi');
      if (pi) pi.textContent = (i + 1) + '/' + wrappers.length;
      persist();
      // تحميل الفصل التالي مسبقاً (نص خفيف فقط) عند تجاوز 60%
      if (!prefetched && neighbors.next != null && i >= wrappers.length * 0.6) {
        prefetched = true;
        api('/chapter/' + encodeURIComponent(slug) + '/' + neighbors.next).catch(() => {});
      }
    }

    const onScroll = () => {
      const y = window.scrollY;
      const rd = $('#rd');
      if (rd) {
        if (y > lastY + 10) rd.classList.add('hide');
        else if (y < lastY - 10) rd.classList.remove('hide');
      }
      lastY = y;
      clearTimeout(tick);
      tick = setTimeout(track, 250);
    };

    function paintPages(imgs) {
      pagesBox.textContent = '';
      io = new IntersectionObserver((entries) => {
        entries.forEach((en) => { if (en.isIntersecting) { loadPage(en.target); io.unobserve(en.target); } });
      }, { rootMargin: '2200px 0px' }); // نحمّل قبل ظهور الصورة بحوالي شاشتين
      imgs.forEach((u, i) => {
        const w = document.createElement('div');
        w.className = 'pg';
        w.dataset.src = u;
        pagesBox.appendChild(w);
        wrappers.push(w);
        io.observe(w);
      });
      pagesBox.onclick = () => $('#rd').classList.toggle('hide');
      $('#pi').textContent = '1/' + imgs.length;
      window.addEventListener('scroll', onScroll, { passive: true });

      if (resume > 0 && resume < wrappers.length) {
        idx = resume;
        [resume - 1, resume, resume + 1].forEach((i) => wrappers[i] && loadPage(wrappers[i]));
        requestAnimationFrame(() => wrappers[resume].scrollIntoView());
        toast('استكمال من الصفحة ' + (resume + 1));
      }
    }

    function paintEnd() {
      const end = $('#rend');
      const bp = $('#bprev'), bn = $('#bnext');
      if (!end) return;
      const go = (c) => { location.hash = '#/read/' + encodeURIComponent(slug) + '/' + c; };
      if (neighbors.prev != null) { bp.disabled = false; bp.onclick = () => go(neighbors.prev); }
      if (neighbors.next != null) {
        bn.disabled = false; bn.onclick = () => go(neighbors.next);
        end.innerHTML = '<a class="btn primary" href="#/read/' + encodeURIComponent(slug) + '/' + neighbors.next + '">الفصل التالي</a>';
      } else {
        end.innerHTML = '<span>هذا آخر فصل متاح</span><a class="btn" href="#/manhwa/' + encodeURIComponent(slug) + '">قائمة الفصول</a>';
      }
    }

    // الصور
    api('/chapter/' + encodeURIComponent(slug) + '/' + encodeURIComponent(num)).then((ch) => {
      if (my !== rid) return;
      const imgs = (ch.images || []).map(httpsOnly).filter(Boolean);
      if (!imgs.length) throw new Error('لا توجد صور لهذا الفصل');
      paintPages(imgs);
    }).catch((e) => {
      if (my !== rid) return;
      pagesBox.innerHTML = errorBox(e);
      pagesBox.querySelector('[data-retry]').onclick = () => window.dispatchEvent(new HashChangeEvent('hashchange'));
    });

    // العمل (للعنوان والفصل السابق/التالي)
    api('/series/' + encodeURIComponent(slug)).then((s) => {
      if (my !== rid) return;
      meta = { title: s.title, cover: s.cover };
      const list = s.chapters || [];
      const i = list.indexOf(n);
      if (i >= 0) neighbors = { prev: i > 0 ? list[i - 1] : null, next: i < list.length - 1 ? list[i + 1] : null };
      const rt = $('#rt');
      if (rt) rt.textContent = s.title + ' - الفصل ' + num;
      paintEnd();
    }).catch(() => {}).finally(() => {
      if (my !== rid) return;
      Hist.add({ slug, c: n, title: (meta && meta.title) || slug });
      persist();
    });

    return () => {
      window.removeEventListener('scroll', onScroll);
      clearTimeout(tick);
      if (io) io.disconnect();
      if (wrappers.length) track();
    };
  }

  // ═══════════════════════════════════════════════
  // المفضلة، الروايات، السجل، الإعدادات
  // ═══════════════════════════════════════════════
  function renderFavs() {
    const favs = Favs.list();
    app.innerHTML = '<header class="top"><h1>المفضلة</h1></header>' +
      (favs.length ? '<div class="grid" id="fg"></div>' : '<div class="state"><strong>لا توجد أعمال بعد</strong><p>افتح أي عمل واضغط "أضف للمفضلة".</p></div>');
    const g = $('#fg');
    if (g) favs.forEach((f) => g.appendChild(card(f)));
  }

  function renderNovels() {
    app.innerHTML = '<header class="top"><h1>الروايات</h1></header>' +
      '<div class="state"><strong>لا يوجد محتوى حالياً</strong><p>قسم الروايات جاهز وسيُضاف المحتوى فيه لاحقاً.</p></div>';
  }

  function renderHistory() {
    const l = Hist.list();
    app.innerHTML = '<header class="top"><a class="back" href="#/settings">رجوع</a><h1>سجل القراءة</h1></header>' +
      (l.length
        ? '<div class="list">' + l.map((h) =>
          '<a class="row" href="#/read/' + encodeURIComponent(h.slug) + '/' + h.c + '"><span>' + esc(h.title) + ' - الفصل ' + esc(h.c) + '</span><small>' + esc(fmtDate(h.t)) + '</small></a>').join('') + '</div>'
        : '<div class="state"><strong>السجل فارغ</strong></div>');
  }

  function fmtDate(t) {
    try { return new Date(t).toLocaleString('ar', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; }
  }

  function sizeKB(pred) {
    let n = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('mb_') && pred(k)) n += (k.length + (localStorage.getItem(k) || '').length) * 2;
    }
    return (n / 1024).toFixed(1);
  }

  function renderSettings() {
    const t = Prefs.get().theme;
    const seg = (v, label) => '<button class="btn' + (t === v ? ' on' : '') + '" data-t="' + v + '">' + label + '</button>';
    app.innerHTML = '<header class="top"><h1>الإعدادات</h1></header><div class="set">' +
      '<div class="box"><h3>المظهر</h3><div class="seg">' + seg('dark', 'داكن') + seg('light', 'فاتح') + seg('auto', 'تلقائي') + '</div></div>' +
      '<div class="box"><h3>التخزين على الجهاز</h3>' +
      '<p>الكاش المؤقت: <b id="s-cache">' + sizeKB((k) => k === 'mb_cache') + '</b> ك.ب (ينتهي بعد ساعة)</p>' +
      '<p>المفضلة والتقدم والسجل: <b id="s-data">' + sizeKB((k) => k !== 'mb_cache') + '</b> ك.ب</p>' +
      '<button class="btn" id="c-cache">مسح الكاش</button>' +
      '<a class="btn" href="#/history">سجل القراءة</a>' +
      '<button class="btn danger" id="c-hist">مسح السجل</button></div>' +
      '<div class="box"><h3>الاتصال بالخادم</h3><p id="ping">اضغط للفحص.</p><button class="btn" id="b-ping">فحص الاتصال</button></div>' +
      '<div class="box"><h3>عن التطبيق</h3><p>Moonbook 0.1.0. الصور تُعرض من مصدرها مباشرة ولا تُخزَّن.</p></div></div>';

    $('.seg').onclick = (e) => {
      const b = e.target.closest('[data-t]');
      if (!b) return;
      Prefs.set({ theme: b.dataset.t });
      renderSettings();
    };
    const refresh = () => { $('#s-cache').textContent = sizeKB((k) => k === 'mb_cache'); $('#s-data').textContent = sizeKB((k) => k !== 'mb_cache'); };
    $('#c-cache').onclick = () => { Cache.clear(); refresh(); toast('تم مسح الكاش'); };
    $('#c-hist').onclick = () => { Hist.clear(); refresh(); toast('تم مسح السجل'); };
    $('#b-ping').onclick = async () => {
      const p = $('#ping');
      p.textContent = 'جارٍ الفحص…';
      try {
        const r = await fetch(WORKER + '/');
        const d = await r.json();
        p.textContent = d.ok ? 'الخادم يعمل.' : 'رد غير متوقع من الخادم.';
      } catch (e) { p.textContent = navigator.onLine ? 'تعذّر الوصول للخادم.' : 'لا يوجد اتصال بالإنترنت.'; }
    };
  }

  // ═══ التوجيه والإقلاع ═══
  Router.add('/', route(renderHome));
  Router.add('/manhwa/:slug', route(renderSeries));
  Router.add('/read/:slug/:num', route(renderReader));
  Router.add('/favorites', route(renderFavs));
  Router.add('/novels', route(renderNovels));
  Router.add('/history', route(renderHistory));
  Router.add('/settings', route(renderSettings));

  Router.after((path) => {
    document.body.classList.toggle('reading', path.startsWith('/read/'));
    const base = path.startsWith('/manhwa/') || path.startsWith('/read/') ? '/' : path === '/history' ? '/settings' : path;
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.r === base));
  });

  applyTheme();
  syncOnline();
  if (navigator.onLine) Cache.sweep();
  Router.start();
})();
