// ═══════════════════════════════════════════════
// router.js — تنقل بسيط بالـ hash (SPA)
// كل مسار يسجّل دالة ترجع (اختيارياً) دالة تنظيف
// ═══════════════════════════════════════════════
window.Router = (() => {
  const routes = [];
  const afterHooks = [];
  let cleanup = null;

  // تسجيل مسار مثل: /manhwa/:slug
  function add(pattern, handler) {
    const keys = [];
    const src = pattern.replace(/:([a-z]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; });
    routes.push({ re: new RegExp('^' + src + '$'), keys, handler });
  }

  function current() {
    return (location.hash.slice(1) || '/').split('?')[0];
  }

  function dispatch() {
    const path = current();
    // تنظيف الصفحة السابقة (مستمعات، مراقبات...)
    if (cleanup) { try { cleanup(); } catch (e) {} cleanup = null; }
    window.scrollTo(0, 0);
    for (const r of routes) {
      const m = path.match(r.re);
      if (!m) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      const res = r.handler(params);
      if (typeof res === 'function') cleanup = res;
      afterHooks.forEach((fn) => fn(path));
      return;
    }
    location.replace('#/');
  }

  function go(path) { location.hash = '#' + path; }
  function after(fn) { afterHooks.push(fn); }
  function start() { window.addEventListener('hashchange', dispatch); dispatch(); }

  return { add, go, after, start, current };
})();
