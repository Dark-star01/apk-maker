// NativeBridge — the ONLY place the web UI talks to Kotlin.
// The UI calls these plain async functions; it never sees Capacitor or plugin names.
// When running in a normal browser (no native side) calls degrade gracefully or reject
// with code NO_NATIVE.

const PLUGIN = 'MvmBridge';

function plugin() {
  const cap = globalThis.Capacitor;
  return cap && cap.Plugins ? cap.Plugins[PLUGIN] || null : null;
}

// Every failure reaches the UI as an Error with a stable `code` (see ui/messages.js).
function toError(e) {
  const err = new Error((e && e.message) || 'Bridge error');
  err.code = (e && e.code) || 'UNEXPECTED';
  return err;
}

function need() {
  const p = plugin();
  if (!p) {
    const err = new Error('Native engine not available');
    err.code = 'NO_NATIVE';
    throw err;
  }
  return p;
}

async function call(method, args) {
  const p = need();
  try {
    return await p[method](args);
  } catch (e) {
    throw toError(e);
  }
}

// Plain facts about the runtime, so a failure can be classified without guessing.
function diagnose() {
  const cap = globalThis.Capacitor;
  const lines = [];
  lines.push('Capacitor object: ' + (cap ? 'yes' : 'NO'));
  if (cap) {
    let platform = '?', native = '?';
    try { platform = cap.getPlatform(); } catch (e) { platform = 'error'; }
    try { native = String(cap.isNativePlatform()); } catch (e) { native = 'error'; }
    lines.push('Platform: ' + platform + ' · isNativePlatform: ' + native);
    lines.push('Plugins: ' + (cap.Plugins ? Object.keys(cap.Plugins).join(', ') || '(none)' : '(no Plugins)'));
    lines.push('PluginHeaders: ' + (cap.PluginHeaders ? cap.PluginHeaders.map((x) => x.name).join(', ') || '(none)' : '(none)'));
  }
  lines.push('androidBridge: ' + (globalThis.androidBridge ? 'yes' : 'no'));
  lines.push(PLUGIN + ': ' + (plugin() ? 'registered' : 'MISSING'));
  return lines;
}

// Asks the always-registered MvmDiag plugin what native registration really did (works even if MvmBridge is missing).
async function nativeReport() {
  const cap = globalThis.Capacitor;
  const d = cap && cap.Plugins ? cap.Plugins.MvmDiag : null;
  if (!d) return 'MvmDiag: MISSING (native files / MainActivity.kt not in this APK)';
  try { const r = await d.report(); return r.text; } catch (e) { return 'MvmDiag error: ' + ((e && e.message) || e); }
}

export const bridge = {
  diagnose,
  nativeReport,
  isNative() { return plugin() !== null; },

  // Health check: proves the Web -> Kotlin -> Web round trip works.
  async ping(value = 'ping') {
    if (!plugin()) return { ok: false, native: false };
    const res = await call('ping', { value });
    return { ...res, native: true };
  },

  // Device facts used later to pick safe preview/export settings.
  async getInfo() {
    if (!plugin()) return { native: false };
    const res = await call('getInfo');
    return { ...res, native: true };
  },

  // Opens the Android file picker. kind: 'audio' | 'image'.
  // Resolves { cancelled: true } or { cancelled: false, kind, media } once the file is
  // copied into the project folder and validated.
  pickMedia(kind, projectId) {
    return call('pickMedia', { kind, projectId });
  },

  // Which referenced files still exist: { audio?: bool, background?: bool }.
  checkMedia(projectId, files) {
    return call('checkMedia', { projectId, audio: files.audio, background: files.background });
  },

  // Small JPEG data URL for the background, or null.
  async getThumbnail(projectId, file) {
    const res = await call('getThumbnail', { projectId, file });
    return (res && res.dataUrl) || null;
  },

  // Removes a project's files from disk (no-op outside the app).
  // ── Playback (all of it runs in Kotlin; JS only sends commands and shows the state) ──
  // Every command resolves the same snapshot: { state, positionMs, durationMs, error? }
  // state: idle | ready | playing | paused | ended | error
  loadAudio(projectId, file) { return call('loadAudio', { projectId, file }); },
  play() { return call('play'); },
  pause() { return call('pause'); },
  seek(positionMs) { return call('seek', { positionMs: Math.round(positionMs) }); },
  stop() { return call('stop'); },
  getPlaybackState() { return call('getPlaybackState'); },
  releaseAudio() { return call('releaseAudio'); },
  // Native pushes the snapshot 4x/second while playing and on every state change.
  onPlayback(cb) {
    const p = plugin();
    if (!p || typeof p.addListener !== 'function') return null;
    try { return p.addListener('playback', cb); } catch (e) { return null; }
  },

  // ── Audio analysis (Kotlin computes it; JS only asks and draws) ──
  // analyzeAudio resolves when the cache file is written (or was already valid): { cached, sampleRate, count, durationMs }.
  analyzeAudio(projectId, file, durationMs, force) { return call('analyzeAudio', { projectId, file, durationMs, force: !!force }); },
  // { sampleRate, count, durationMs, data: base64 } or rejects NO_WAVE_DATA (never stale data).
  getWaveData(projectId, file) { return call('getWaveData', { projectId, file }); },
  cancelAnalysis() { return call('cancelAnalysis'); },
  onAnalysisProgress(cb) {
    const p = plugin();
    if (!p || typeof p.addListener !== 'function') return null;
    try { return p.addListener('analysisProgress', cb); } catch (e) { return null; }
  },

  // ── Effects (Kotlin EffectEngine; JS never computes effect values) ──
  // Resolves the EffectState for one instant: { timeMs, scale, rotationDeg, translateX, translateY, opacity, glow,
  // intensity, shake, audioReactive, audio: { amplitude, bass, mid, treble } }. Never analyses audio or reads it.
  getEffectState({ projectId, file, timeMs, durationMs, effects, aspect }) {
    return call('getEffectState', { projectId, file: file || null, timeMs, durationMs: durationMs || 0, effects, aspect });
  },

  // ── Native Preview renderer (Kotlin draws on a TextureView over #preview; JS only places it and describes the project) ──
  // rect = { x, y, width, height, dpr, visible }  (CSS pixels of #preview + devicePixelRatio)
  attachPreview(rect) { return call('attachPreview', rect); },
  setPreviewRect(rect) { return call('setPreviewRect', rect); },
  detachPreview() { return call('detachPreview'); },
  // { projectId, background, audioFile, durationMs, effects, aspect }: no pixels, only names and settings.
  setPreviewProject(p) { return call('setPreviewProject', p); },
  // { renderer, surface, frame, timeMs, fps, targetFps, frames, drawMs, imageW, imageH, background, audioReactive, error? }
  getRendererState() { return call('getRendererState'); },
  // Renders timeMs twice (and otherMs once) offscreen with the real Renderer: { identical, crcA, crcB, crcOther, ... }
  rendererSelfTest(args) { return call('rendererSelfTest', args); },

  // ── Export (Phase 7: Kotlin renders with the shared Renderer and encodes with MediaCodec; JS starts, polls and cancels) ──
  // startExport resolves at once ({ ok }); the work runs natively. Poll getExportState() about once a second:
  // { state: idle|preparing|encodingAudio|rendering|finalizing|completed|failed|cancelled, percent, frame, frames, width, height, fps,
  //   outputPath?, outputName?, sizeBytes?, durationMs?, errorCode?, errorMessage?, detail? }   No frame ever crosses the bridge.
  startExport(p) { return call('startExport', p); },
  cancelExport() { return call('cancelExport'); },
  getExportState() { return call('getExportState'); },
  shareExport(path) { return call('shareExport', { path }); },
  openExport(path) { return call('openExport', { path }); },

  async removeMedia(projectId, kind) {
    if (!plugin()) return;
    await call('removeMedia', { projectId, kind });
  },

  async deleteProject(projectId) {
    if (!plugin()) return;
    await call('deleteProject', { projectId });
  },
};
